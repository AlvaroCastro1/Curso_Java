import java.util.*;
import java.util.stream.Stream;
import java.util.function.*;


public class CuentaPalabras{


	public static void main(String[] args) {
		
		CuentaPalabras c = new CuentaPalabras();
		String palabra = "Esta es una frase con varias palabras";
		Function <String,Integer> cuentaPalabras = pal -> {

			int i = (int)Stream.of(palabra.split(" "))
				.count();
			return i;
		};

		System.out.println("la frase " + palabra + " contiene " + cuentaPalabras.apply(palabra) + " palabras ");

	}

}