import java.util.*;
import java.util.stream.*;
import java.util.function.*;
import java.lang.*;
import java.io.*;

public class TresDigitos{
	
	public void imprime3(List pals){

		pals.stream()
			//.map(x->x.substring())
			.forEach(a->{
				String x = a.toString();
				System.out.println(x.substring(x.length()-3,x.length()));});

	}

	public static void main(String[] args) {
		
		TresDigitos t = new TresDigitos();
		List<String> lista = new ArrayList<String>();
		lista.add("pal1");
		lista.add("pal2");
		lista.add("pal3");
		lista.add("pal4");
		lista.add("pal5");
		lista.add("pal6");
		lista.add("pal7");
		lista.add("pal8");
		lista.add("pal9");

		t.imprime3(lista);


	}

}