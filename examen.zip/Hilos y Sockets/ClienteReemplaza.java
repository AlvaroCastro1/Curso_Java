import java.util.*;
import java.lang.*;
import java.net.*;
import java.io.*;


public class ClienteReemplaza{
	
	Socket sock;
	PrintWriter pw;
	String mensaje;
	String miNombre="";

	public void inicia(){

		try{
			sock = new Socket("192.168.137.1",33333);
			pw = new PrintWriter(sock.getOutputStream());
			Lector lector= new Lector();
			lector.start();
		}catch(IOException e){e.printStackTrace();}
		//catch(){}

	}

	class Lector extends Thread{

		public void run(){

			try{

				InputStreamReader sr = new InputStreamReader(sock.getInputStream());
				BufferedReader bf = new BufferedReader(sr);

				while(  true ){

					if( (mensaje=bf.readLine())!=null ){

						System.out.println(mensaje);

						if(mensaje.equals("eres")){

							miNombre=bf.readLine();

						}//if

					}//if 
						
					

				}//while


			}catch(IOException e){e.printStackTrace();}


		}//run


	} //lector

	public void consulta(String frase){

		pw.println("evalua");
		pw.println(miNombre);
		pw.println(frase);
		pw.flush();

	}

	public static void main(String[] args) {
			
		ClienteReemplaza cr = new ClienteReemplaza();
		cr.inicia();
		try{Thread.sleep(100);}catch(InterruptedException i){i.printStackTrace();}
		cr.consulta("esta1723 aaaaaaaaes una frase@@@*+++´ñ+");
		System.out.println("la frase es : " + "esta1723 es una frase");
	}

}