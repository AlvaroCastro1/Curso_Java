import java.util.*;
import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.stream.*;

public class ServerRemplaza{
	

	ServerSocket ss;
	Socket sock;
	ArrayList<Socket> usuarios = new ArrayList<Socket>();
	ArrayList<PrintWriter> pws = new ArrayList<PrintWriter>();

	String quien="";
	String mensaje="";


	public void inicia(){

		try{

			ss = new ServerSocket(33333);
			Conexion c = new Conexion();
			c.start();

		}catch(IOException e){e.printStackTrace();}

	}

	public void reemplazaNumeros(String palabra){

		System.out.println("palabra sin numeros: ");
		Stream.of(palabra.split(""))
			.forEach(x-> {
				if(x.equals("1") ||
					x.equals("2") ||
					x.equals("3") ||
					x.equals("4") ||
					x.equals("5") ||
					x.equals("6") ||
					x.equals("7") ||
					x.equals("8") ||
					x.equals("9") ||
					x.equals("0")){
						x="#";

					}
				System.out.print(x);
			});
			System.out.println();

	}//reemplazaNumeros

	public void menoraQ(String p){

		Stream.of(p.split(""))
			.filter( x ->x.compareToIgnoreCase("q")<0)
			.forEach(System.out::print);

	}
	public void sinLetras(String p){

		System.out.println("\n en funcion sin letras");
		Stream.of(p.split(""))
			.filter(letra -> !letra.equals("a") && 
				!letra.equals("b") &&
				!(letra.equals("c")) &&
				!(letra.equals("d")) &&
				!(letra.equals("e")) &&
				!(letra.equals("f")) &&
				!(letra.equals("g")) &&
				!(letra.equals("h")) &&
				!(letra.equals("i")) &&
				!(letra.equals("j")) &&
				!(letra.equals("k")) &&
				!(letra.equals("l")) &&
				!(letra.equals("m")) &&
				!(letra.equals("n")) &&
				!(letra.equals("ñ")) &&
				!(letra.equals("o")) &&
				!(letra.equals("p")) &&
				!(letra.equals("q")) &&
				!(letra.equals("r")) &&
				!(letra.equals("s")) &&
				!(letra.equals("t")) &&
				!(letra.equals("u")) &&
				!(letra.equals("v")) &&
				!(letra.equals("w")) &&
				!(letra.equals("x")) &&
				!(letra.equals("y")) &&
				!(letra.equals("z")) &&
				!(letra.equals("1")) &&
				!(letra.equals("2")) &&
				!(letra.equals("3")) &&
				!(letra.equals("4")) &&
				!(letra.equals("5")) &&
				!(letra.equals("6")) &&
				!letra.equals("7") &&
				!letra.equals("8") &&
				!letra.equals("9") &&
				!letra.equals("0") &&
				!letra.equals("%")
				)
			.forEach(System.out::print);// ||
				// !(x.equals("b")) ||
				// !(x.equals("c")) ||
				// !(x.equals("d")) ||
				// !(x.equals("e")) ||
				// !(x.equals("f")) ||
				// !(x.equals("g")) ||
				// !(x.equals("h")) ||
				// !(x.equals("i")) ||
				// !(x.equals("j")) ||
				// !(x.equals("k")) ||
				// !(x.equals("l")) ||
				// !(x.equals("m")) ||
				// !(x.equals("n")) ||
				// !(x.equals("ñ")) ||
				// !(x.equals("o")) ||
				// !(x.equals("p")) ||
				// !(x.equals("q")) ||
				// !(x.equals("r")) ||
				// !(x.equals("s")) ||
				// !(x.equals("t")) ||
				// !(x.equals("u")) ||
				// !(x.equals("v")) ||
				// !(x.equals("w")) ||
				// !(x.equals("x")) ||
				// !(x.equals("y")) ||
				// !(x.equals("z")) ||
				// !(x.equals("1")) ||
				// !(x.equals("2")) ||
				// !(x.equals("3")) ||
				// !(x.equals("4")) ||
				// !(x.equals("5")) ||
				// !(x.equals("6")) ||
				// !(x.equals("7")) ||
				// !(x.equals("8")) ||
				// !(x.equals("9")) ||
				// !(x.equals("0")) ||
				// !(x.equals("%")) 

			//){
			//	System.out.print(x);
			//}//if
			//); //Stream

	}
		

	class Conexion extends Thread{

		public void run(){

			try{

				while ( true ){

					sock = ss.accept();
					PrintWriter pw = new PrintWriter(sock.getOutputStream());
					pws.add(pw);
					pw.println("eres");
					pw.println(""+pws.size());
					pw.flush();
					Escuchador e = new Escuchador();
					e.start();
				} 

			}catch(IOException e){ e.printStackTrace();}

		}//run

	}//Consexion


	class Escuchador extends Thread{

		public void run(){

			try{

				InputStreamReader ir = new InputStreamReader(sock.getInputStream());
				BufferedReader bf = new BufferedReader(ir);
				while( true ){

					if( (mensaje=bf.readLine())!=null ){
						System.out.println("mensaje: " + mensaje);
						if(mensaje.equals("evalua")){

							quien=bf.readLine();
							String frase=bf.readLine();
							reemplazaNumeros(frase);
							menoraQ(frase);
							sinLetras(frase);

						}

					}//if

				}//while

			}catch(IOException x){x.printStackTrace();}

		}//run

		public void avisaUno(String quien , String frase){

			pws.get(Integer.parseInt(quien)-1).println(frase);
			pws.get(Integer.parseInt(quien)-1).flush();

		}

	}//Escuchador 


	public static void main(String[] args) {
	
		ServerRemplaza sr = new ServerRemplaza();
		sr.inicia();

	}

}