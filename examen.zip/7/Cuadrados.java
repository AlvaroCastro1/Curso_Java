
import java.util.*;
import java.util.stream.*;
import java.lang.*;
import java.util.function.*;
import java.lang.Math;

public class Cuadrados{
	
	public static void main(String[] args) {
		
		Supplier <Double> s = ()->{

		Double i = Stream.generate(new Random()::nextInt)
				.limit(10)
				.mapToDouble(x-> Math.pow(x,2))
				.sum();
				return i;
		};
		System.out.println(s.get());
	}

}