import java.util.function.*;
import java.util.*;
import java.util.stream.Stream;

public class MenosdeDosNumeros{
	
	public static void main(String[] args) {
		String pal = "Hola123";
		ArrayList<String> letras = new ArrayList<String>(); 

		Consumer <ArrayList<String>> c = p -> {
		//Consumer <String> c = p -> {
			a = new Arrays();
			a = (Arrays) p.stream().filter(x-> x.equals("0") ||
						x.equals("1") ||
						x.equals("2") ||
						x.equals("3") ||
						x.equals("4") ||
						x.equals("5") ||
						x.equals("6") ||
						x.equals("7") ||
						x.equals("8") ||
						x.equals("9"));
			// System.out.println("tiene " + a.size());
		};//consumer
		for ( int i =0; i< pal.length();i++){
			letras.add(""+pal.charAt(i));
		}
		c.accept(letras);
		//c.accept(pal);
	}

}