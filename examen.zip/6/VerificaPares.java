
import java.util.*;
import java.util.stream.*;
import java.lang.*;
import java.util.function.*;
import java.lang.Math;
public class VerificaPares{

	public static void main(String[] args) {
		
		Consumer <Integer> s = (n)->{
			Random r = new Random();
			if(Stream.generate(new Random()::nextInt)
					.limit(n)
					.filter(x-> x%2==0)
					.count()>n){
					System.out.println("todos son pares");
			}else{
				System.out.println("Nom todos son pares");
			}

		};//cosnumer

		s.accept(10);

	}
}