
import java.util.function.*;
import java.util.*;
import java.util.stream.Stream;

public class Diferencia{
	
	public static void main(String[] args) {
		
		BiFunction <Character,Character,Integer> diferencia = (x,y) -> (""+x).compareTo(""+y); 
		System.out.println(diferencia.apply('a','w'));

	}

}