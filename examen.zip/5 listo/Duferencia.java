
import java.util.function.*;
import java.util.*;
import java.util.stream.Stream;

public class Diferencia{
	
	
	
}