import java.util.*;
import java.lang.*;
import java.net.*;
import java.io.*;

public class ServerOctal {
		
		ServerSocket ss;
		Socket sock;
		ArrayList<Socket> usuarios = new ArrayList<Socket>();
		ArrayList<PrintWriter> pws = new ArrayList<PrintWriter>();
		String mensaje="";
		String numero="";
		String quien="";


		public void inicio(){
			
			try{
				ss = new ServerSocket(6666);
				Conecta c = new Conecta();
				c.start();
			}catch(IOException e){
				e.printStackTrace();
			}
		}


	class Conecta extends Thread{

		public void run(){

			try{

			while(true){

				sock = ss.accept();
				usuarios.add(sock);
				//input  leer    output escribir
				PrintWriter pw = new PrintWriter(sock.getOutputStream());
				pws.add(pw);
				//pw = System.out.
				pw.println("eres");
				pw.println(""+pws.size()); // eres "1"
				pw.flush();
				Lee lector = new Lee();
				lector.start();


			}

			}catch(IOException e){
				e.printStackTrace();
			}

		}

	}//conecta

	class Lee extends Thread{

		public void run(){

			try{
				//System.in
				InputStreamReader sr = new InputStreamReader(sock.getInputStream());
				BufferedReader bf = new BufferedReader(sr);
			
				while( true ){

					if((mensaje=bf.readLine())!=null){

						System.out.println("menasje: "+mensaje);
						if(mensaje.equals("evalua")){

							numero = bf.readLine();
							quien=bf.readLine();

							avisarAUno(quien,""+evalua(numero));

						}
					
					}

				}

			}catch(IOException o ){

				o.printStackTrace();

			}


		}//run

		public int evalua(String num){
												// 3210		
			int aux = Integer.parseInt(num); //    612
 			int decimal=0;
			int exponente=0;
			while(aux>0){

				decimal += aux%10 * Math.pow(8,exponente);
							//2    *    8
				exponente++;
				aux=aux/10;
			}

			return decimal;
		}

		public void avisarAUno(String qui , String mensaje){ //("1","mensaje")

			int posicion = Integer.parseInt(qui);
			pws.get(posicion-1).println(mensaje);
			pws.get(posicion-1).flush();

		}

	}


	public static void main(String[] args) {
		
		ServerOctal so = new ServerOctal();
		so.inicio();
		

	}

}