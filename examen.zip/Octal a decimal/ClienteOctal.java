import java.util.*;
import java.lang.*;
import java.net.*;
import java.io.*;

public class ClienteOctal{
	
	Socket sock;
	String mensaje="";
	String miNombre="";
	PrintWriter pw;

	public void inicio(){

		try{
			sock = new Socket("192.168.137.1",6666);
			Lee lector = new Lee();
			pw = new PrintWriter(sock.getOutputStream());
			lector.start();
		}catch(IOException ex){
			ex.printStackTrace();
		}
	}

	public void consulta(String mensaje){

		pw.println("evalua");
		pw.println(mensaje);
		pw.println(miNombre);
		pw.flush();

	}

	class Lee extends Thread{

		public void run(){
			
			try{
				InputStreamReader sr = new InputStreamReader(sock.getInputStream());
				BufferedReader bf = new BufferedReader(sr);

				while( true){

					if((mensaje=bf.readLine())!=null ){
						System.out.println(mensaje);
						if(mensaje.equals("eres")){

							miNombre=bf.readLine();

						}
					}

				}
			}catch(IOException e){

				e.printStackTrace();

			}
		}//

	}//lee



	public static void main(String[] args) {
		
		ClienteOctal co = new ClienteOctal();
		co.inicio();
		try{Thread.sleep(100);}catch(InterruptedException e){
			e.printStackTrace();
		}
		co.consulta("54");

	}

}