import java.util.*;
import java.lang.*;
import java.util.*;
import java.io.*;


public class Matriz implements Runnable{
	
	int n=0;
	Integer[][] matriz;

	public Matriz(int n){

		this.n = n;
		this.matriz = new Integer[n][2*n];
		//generaMatriz();
		//imprimeMatriz();
	}

	public void run(){
		//como trabaja cada hilo independiente
		for(int hilo =0; hilo< this.n ; hilo++){

			if(Thread.currentThread().getName().equals(""+hilo)){

				System.out.println("entrando en hilo: " + hilo);

				for(int j=0; j<2*this.n; j++){

					matriz[hilo][j] = (new Random().nextInt(100));


				}//for

			}
		
		}

	}

	// public void generaMatriz(){



	// 	for(int i=0; i<this.n; i++){

	// 		for(int j=0; j<2*this.n; j++){

	// 			matriz[i][j] = (new Random().nextInt(100));


	// 		}//for

	// 	}//for

	// }//genM
	public void imprimeMatriz(){

		for(int i=0; i<this.n; i++){

			for(int j=0; j<2*this.n; j++){

				System.out.print(matriz[i][j] + ", "); 


			}//for
			System.out.println();

		}//for

	}//imprime

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int n =0;
		System.out.println("\nDame el tamaño n: " );
		n=sc.nextInt();

		Matriz m = new Matriz(n);
		for(int i=0; i<n; i++){

			Thread h = new Thread(m,""+i);
			h.start();

		}
		try{Thread.sleep(100);}catch(InterruptedException i){ i.printStackTrace();}
		m.imprimeMatriz();

	}


}